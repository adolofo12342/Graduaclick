document.addEventListener('DOMContentLoaded', function() {
    const btnRequisitos = document.querySelector('.botondocumentacion');

    btnRequisitos.addEventListener('click', function(e) {
        e.preventDefault();
    
    });
});