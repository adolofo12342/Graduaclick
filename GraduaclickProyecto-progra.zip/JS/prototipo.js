const fotoInput = document.getElementById('fotoAlumno');
const fotoPreview = document.getElementById('fotoPreview');
if (fotoInput && fotoPreview) {
  fotoInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(evt) {
        fotoPreview.src = evt.target.result;
      };
      reader.readAsDataURL(file);
    }
  });
}

document.getElementById('formPrototipo').addEventListener('submit', function(e) {
  e.preventDefault();

  const docs = [
    { id: 'fileActaNacimiento', keyword: 'acta' },
    { id: 'fileCurp', keyword: 'curp' },
    { id: 'fileCertificadoSecundaria', keyword: 'secundaria' },
    { id: 'fileCertificadoBachillerato', keyword: 'bachillerato' },
    { id: 'fileCartaLiberacionSS', keyword: 'servicio' },
    { id: 'fileCartaLiberacionPracticas', keyword: 'practica' },
    { id: 'fileConstanciasCompetencia', keyword: 'constancia' },
    { id: 'fileFotografiasDiploma', keyword: 'diploma' },
    { id: 'fileFotografiasTitulo', keyword: 'titulo' },
    { id: 'filePagoBancomer', keyword: 'bancomer' }
  ];

  let valido = true;
  let mensaje = '';

  docs.forEach(function(doc) {
    const input = document.getElementById(doc.id);
    const file = input.files[0];
    input.classList.remove('input-error');

    if (file) {
      const validTypes = ['application/pdf', 'image/jpeg', 'image/png'];
      if (!validTypes.includes(file.type)) {
        valido = false;
        mensaje += `El archivo de "${input.previousElementSibling.textContent}" debe ser PDF, JPG o PNG.\n`;
        input.classList.add('input-error');
      }
    } else {
      valido = false;
      mensaje += `Debe adjuntar el archivo de "${input.previousElementSibling.textContent}".\n`;
      input.classList.add('input-error');
    }
  });

  if (!valido) {
    alert(mensaje);
    return;
  }

  const form = e.target;
  const data = {
    id: Date.now(),
    tipo_titulacion: 'prototipo',
    fecha: form.fecha.value,
    turno: form.turno.value,
    grupo: form.grupo.value,
    nombre: form.nombre.value,
    especialidad: form.especialidad.value,
    no_de_control: form.no_de_control.value,
    no_de_celular: form.no_de_celular.value,
    no_de_tel_adicional: form.no_de_tel_adicional.value,
    correo_electronico: form.correo_electronico.value,
    nombre_proyecto: form.nombre_proyecto ? form.nombre_proyecto.value : '',
    asesor: form.asesor ? form.asesor.value : '',
    documentos: {}
  };

  docs.forEach(doc => {
    const input = document.getElementById(doc.id);
    if (input && input.files[0]) {
      data.documentos[doc.id] = URL.createObjectURL(input.files[0]);
    }
  });

  const arr = JSON.parse(localStorage.getItem('formulariosUsuarios') || '[]');
  arr.push(data);
  localStorage.setItem('formulariosUsuarios', JSON.stringify(arr));

  alert('Tu información fue enviada correctamente');
  setTimeout(() => {
    window.open('reporte_usuario.html?id=' + data.id, '_blank');
  }, 5000);
  form.reset();
});

const style = document.createElement('style');
style.innerHTML = `
.input-error {
  border: 2px solid #e74c3c !important;
  background: #fff6f6 !important;
}
`;
document.head.appendChild(style);