function manejarCambioArchivo(inputFile, checkboxId) {
    const checkbox = document.getElementById(checkboxId);
    checkbox.checked = inputFile.files.length > 0;
}

document.addEventListener('DOMContentLoaded', function() {
    const documentos = [
        { fileId: 'fileActaNacimiento', checkboxId: 'actaNacimiento' },
        { fileId: 'fileCurp', checkboxId: 'curpDoc' },
        { fileId: 'fileCertificadoSecundaria', checkboxId: 'certificadoSecundaria' },
        { fileId: 'fileCertificadoBachillerato', checkboxId: 'certificadoBachillerato' },
        { fileId: 'fileCartaLiberacionSS', checkboxId: 'cartaLiberacionSS' },
        { fileId: 'fileCartaLiberacionPracticas', checkboxId: 'cartaLiberacionPracticas' },
        { fileId: 'fileConstanciasCompetencia', checkboxId: 'constanciasCompetencia' },
        { fileId: 'fileFotografiasDiploma', checkboxId: 'fotografiasDiploma' },
        { fileId: 'fileFotografiasTitulo', checkboxId: 'fotografiasTitulo' },
        { fileId: 'filePagoBancomer', checkboxId: 'pagoBancomer' }
    ];

    documentos.forEach(doc => {
        const inputFile = document.getElementById(doc.fileId);
        const checkbox = document.getElementById(doc.checkboxId);

        if (inputFile && checkbox) {
            inputFile.addEventListener('change', function() {
                manejarCambioArchivo(this, doc.checkboxId);
            });

            if (inputFile.files.length > 0) {
                checkbox.checked = true;
            }
        }
    });

    const formTitulacion = document.getElementById('formTitulacion');
    if (formTitulacion) {
        formTitulacion.addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(formTitulacion);
            const datosUsuario = {};

            formData.forEach((value, key) => {
                datosUsuario[key] = value;
            });

            datosUsuario.tipo_titulacion = 'directa';

            datosUsuario.empresa = formTitulacion.empresa ? formTitulacion.empresa.value : '';
            datosUsuario.puesto = formTitulacion.puesto ? formTitulacion.puesto.value : '';

            datosUsuario.documentos = {};
            documentos.forEach(doc => {
                const inputFile = document.getElementById(doc.fileId);
                if (inputFile.files.length > 0) {
                    datosUsuario.documentos[doc.checkboxId] = URL.createObjectURL(inputFile.files[0]);
                }
            });

            datosUsuario.id = Date.now();

            let formulariosUsuarios = JSON.parse(localStorage.getItem('formulariosUsuarios') || '[]');
            formulariosUsuarios.push(datosUsuario);
            localStorage.setItem('formulariosUsuarios', JSON.stringify(formulariosUsuarios));

            alert('Formulario enviado correctamente');
            formTitulacion.reset();
        });
    }
});