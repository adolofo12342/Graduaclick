document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('formulario-inicio-sesion');
    const usuario = document.getElementById('usuario');
    const contrasena = document.getElementById('contrasena');
    const errorUsuario = document.getElementById('error-usuario');
    const errorContrasena = document.getElementById('error-contrasena');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        let valido = true;

        errorUsuario.style.display = 'none';
        errorContrasena.style.display = 'none';

        if (!usuario.value.trim()) {
            errorUsuario.textContent = 'El correo es obligatorio.';
            errorUsuario.style.display = 'block';
            valido = false;
        }

        if (!contrasena.value.trim()) {
            errorContrasena.textContent = 'La contraseña es obligatoria.';
            errorContrasena.style.display = 'block';
            valido = false;
        }

        if (valido) {
            window.location.href = 'p1.html';
        }
    });
});