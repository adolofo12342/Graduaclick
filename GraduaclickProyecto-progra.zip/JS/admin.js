document.getElementById('formulario-admin').addEventListener('submit', function(e) {
    e.preventDefault();
    const codigo = document.getElementById('admin-codigo').value.trim();
    if (codigo === 'ADMINJG1201617') {
        document.querySelector('.contenedor-inicio-sesion').style.display = 'none';
        document.getElementById('admin-panel').style.display = 'block';
        cargarFiltrosYReporte();
    } else {
        document.getElementById('error-admin-codigo').textContent = "Código de acceso incorrecto";
    }
});

const $buscador = document.getElementById('buscador-admin');
const $fTurno = document.getElementById('filtro-turno');
const $fCarrera = document.getElementById('filtro-carrera');
const $fGrupo = document.getElementById('filtro-grupo');
const $fTipo = document.getElementById('filtro-tipo'); // Asegúrate de que este elemento exista en tu HTML del panel.

function cargarFiltrosYReporte() {
    const datos = JSON.parse(localStorage.getItem('formulariosUsuarios') || '[]');

    const turnos = [...new Set(datos.map(d => d.turno).filter(Boolean))];
    $fTurno.innerHTML = '<option value="">Todos</option>' + turnos.map(t => `<option value="${t}">${t}</option>`).join('');

    const carreras = [...new Set(datos.map(d => d.especialidad).filter(Boolean))];
    $fCarrera.innerHTML = '<option value="">Todas</option>' + carreras.map(c => `<option value="${c}">${c}</option>`).join('');

    const grupos = [...new Set(datos.map(d => d.grupo).filter(Boolean))];
    $fGrupo.innerHTML = '<option value="">Todos</option>' + grupos.map(g => `<option value="${g}">${g}</option>`).join('');

    // Filtro por tipo de titulación
    // Aquí puedes generar las opciones dinámicamente si hay más tipos,
    // o mantenerlas estáticas si solo son 'directa' y 'prototipo'.
    // Si quieres que solo aparezcan los tipos que ya existen en los datos:
    // const tipos = [...new Set(datos.map(d => d.tipo_titulacion).filter(Boolean))];
    // $fTipo.innerHTML = '<option value="">Todos</option>' + tipos.map(t => `<option value="${t}">${t}</option>`).join('');
    // O si solo quieres los dos fijos:
    $fTipo.innerHTML = '<option value="">Todos</option>' +
        '<option value="directa">Titulación Directa</option>' +
        '<option value="prototipo">Prototipo</option>';

    renderizaLista();
}

function renderizaLista() {
    const datos = JSON.parse(localStorage.getItem('formulariosUsuarios') || '[]');
    let filtrados = datos;

    if ($fTurno.value) filtrados = filtrados.filter(d => d.turno === $fTurno.value);
    if ($fCarrera.value) filtrados = filtrados.filter(d => d.especialidad === $fCarrera.value);
    if ($fGrupo.value) filtrados = filtrados.filter(d => d.grupo === $fGrupo.value);
    if ($fTipo.value) filtrados = filtrados.filter(d => d.tipo_titulacion === $fTipo.value); // Esto ahora funcionará correctamente

    const q = ($buscador.value || '').toLowerCase();
    if (q) {
        filtrados = filtrados.filter(d =>
            (d.nombre && d.nombre.toLowerCase().includes(q)) ||
            (d.no_de_control && d.no_de_control.toString().includes(q)) ||
            (d.correo_electronico && d.correo_electronico.toLowerCase().includes(q))
        );
    }

    const directa = filtrados.filter(d => d.tipo_titulacion === 'directa');
    const prototipo = filtrados.filter(d => d.tipo_titulacion === 'prototipo');
    const otros = filtrados.filter(d => !d.tipo_titulacion || !['directa', 'prototipo'].includes(d.tipo_titulacion)); // Para formularios sin tipo

    let html = '';

    // Sección Titulación Directa
    if (directa.length > 0) {
        html += `<h3 class="seccion-titulo">Titulación Directa (${directa.length})</h3>`;
        html += generarHTMLLista(directa);
    }

    // Sección Prototipo
    if (prototipo.length > 0) {
        html += `<h3 class="seccion-titulo">Prototipo (${prototipo.length})</h3>`;
        html += generarHTMLLista(prototipo);
    }

    // Sección Otros (por si hay formularios sin tipo definido)
    if (otros.length > 0) {
        html += `<h3 class="seccion-titulo">Otros (${otros.length})</h3>`;
        html += generarHTMLLista(otros);
    }

    if (!filtrados.length) {
        html = '<p style="color:#1976d2;">No se encontraron resultados.</p>';
    }

    document.getElementById('reporte-admin').innerHTML = html;
}

// Función auxiliar para generar el HTML de la lista
function generarHTMLLista(datos) {
    return datos.map(d => `
        <div class="reporte-card" id="card-${d.id}">
            <div class="titulo">${d.nombre} <span style="color:#444;font-weight:400;">(${d.no_de_control})</span></div>
            <div class="detalle">
                <b>Turno:</b> ${d.turno || '-'} &nbsp;
                <b>Especialidad:</b> ${d.especialidad || '-'} &nbsp;
                <b>Grupo:</b> ${d.grupo || '-'}<br>
                <b>Correo:</b> ${d.correo_electronico || '-'}<br>
                <b>Fecha:</b> ${d.fecha || '-'}
            </div>
            <button class="btn-ver" onclick="verDetalleUsuario(${d.id})">Ver Detalle</button>
            <div class="detalle-extra" id="detalle-${d.id}" style="display:none;margin-top:1em;"></div>
        </div>
    `).join('');
}

// Agrega los event listeners a los filtros y al buscador.
// Asegúrate de que estos elementos existan en tu HTML del panel.
[$buscador, $fTurno, $fCarrera, $fGrupo, $fTipo].forEach(el => {
    // Solo agrega el listener si el elemento existe en el DOM
    el && el.addEventListener('input', renderizaLista);
});


window.verDetalleUsuario = function(id) {
    const datos = JSON.parse(localStorage.getItem('formulariosUsuarios') || '[]');
    const d = datos.find(x => x.id === id);
    if (!d) return;

    const contenedor = document.getElementById(`detalle-${id}`);
    if (!contenedor) return;

    // Alternar visibilidad
    if (contenedor.style.display === 'block') {
        contenedor.style.display = 'none';
        contenedor.innerHTML = '';
        return;
    }

    let detalle = `
    <h4>Detalle del Usuario</h4>
    <ul>
        <li><b>Tipo de Titulación:</b> ${d.tipo_titulacion === 'directa' ? 'Titulación Directa' : (d.tipo_titulacion === 'prototipo' ? 'Prototipo' : 'No especificado')}</li>
        <li><b>Nombre:</b> ${d.nombre}</li>
        <li><b>Fecha:</b> ${d.fecha}</li>
        <li><b>Turno:</b> ${d.turno || ''}</li>
        <li><b>Especialidad:</b> ${d.especialidad}</li>
        <li><b>Grupo:</b> ${d.grupo || ''}</li>
        <li><b>No. de Control:</b> ${d.no_de_control}</li>
        <li><b>Correo:</b> ${d.correo_electronico}</li>
        <li><b>Documentos:</b><ul>`;

    Object.keys(d.documentos || {}).forEach(doc => {
        detalle += `<li>${doc}: <a href="${d.documentos[doc]}" target="_blank">Ver archivo</a></li>`;
    });

    detalle += `</ul></li></ul>`;

    // Campos específicos para cada tipo
    if (d.tipo_titulacion === 'directa') {
        detalle += `<ul><li><b>Empresa:</b> ${d.empresa || '-'}</li>`;
        detalle += `<li><b>Puesto:</b> ${d.puesto || '-'}</li></ul>`;
    } else if (d.tipo_titulacion === 'prototipo') {
        detalle += `<ul><li><b>Nombre del Proyecto:</b> ${d.nombre_proyecto || '-'}</li>`;
        detalle += `<li><b>Asesor:</b> ${d.asesor || '-'}</li></ul>`;
    }

    contenedor.innerHTML = detalle;
    contenedor.style.display = 'block';
};